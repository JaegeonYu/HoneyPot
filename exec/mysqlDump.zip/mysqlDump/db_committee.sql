CREATE DATABASE  IF NOT EXISTS `db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: J10B201.p.ssafy.io    Database: db
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `committee`
--

DROP TABLE IF EXISTS `committee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `committee` (
  `cmit_on_off` bit(1) NOT NULL,
  `cmit_id` bigint NOT NULL AUTO_INCREMENT,
  `cmit_code` varchar(255) DEFAULT NULL,
  `cmit_leader` varchar(255) DEFAULT NULL,
  `cmit_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cmit_id`),
  UNIQUE KEY `UK_s0q0svruyiho0xcd9x8s2nv4a` (`cmit_code`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `committee`
--

LOCK TABLES `committee` WRITE;
/*!40000 ALTER TABLE `committee` DISABLE KEYS */;
INSERT INTO `committee` VALUES (_binary '',1,'9700005','윤재옥 (국민의힘)','국회운영위원회'),(_binary '',2,'9700006','김도읍 (국민의힘)','법제사법위원회'),(_binary '',3,'9700008','백혜련 (더불어민주당)','정무위원회'),(_binary '',4,'9700300','김상훈 (국민의힘)','기획재정위원회'),(_binary '',5,'9700512','김철민 (더불어민주당)','교육위원회'),(_binary '',6,'9700479','장제원 (국민의힘)','과학기술정보방송통신위원회'),(_binary '',7,'9700409','김태호 (국민의힘)','외교통일위원회'),(_binary '',8,'9700019','한기호 (국민의힘)','국방위원회'),(_binary '',9,'9700480','김교흥 (더불어민주당)','행정안전위원회'),(_binary '',10,'9700513','이상헌 (무소속)','문화체육관광위원회'),(_binary '',11,'9700408','소병훈 (더불어민주당)','농림축산식품해양수산위원회'),(_binary '',12,'9700481','이재정 (더불어민주당)','산업통상자원중소벤처기업위원회'),(_binary '',13,'9700341','신동근 (더불어민주당)','보건복지위원회'),(_binary '',14,'9700038','박정 (더불어민주당)','환경노동위원회'),(_binary '',15,'9700407','김민기 (더불어민주당)','국토교통위원회'),(_binary '',16,'9700047','박덕흠 (국민의힘)','정보위원회'),(_binary '',17,'9700342','권인숙 (더불어민주연합)','여성가족위원회'),(_binary '',18,'9700049','서삼석 (더불어민주당)','예산결산특별위원회'),(_binary '',19,'9700547',NULL,'국회 2030 부산세계박람회 유치지원 특별위원회'),(_binary '',20,'9700554',NULL,'형사사법체계개혁특별위원회'),(_binary '',21,'9700555','남인순 (더불어민주당)','정치개혁특별위원회'),(_binary '',22,'9700553','주호영 (국민의힘)','연금개혁특별위원회'),(_binary '',23,'9700560','김영선 (국민의힘)','인구위기특별위원회'),(_binary '',24,'9700561','김정호 (더불어민주당)','기후위기특별위원회'),(_binary '',25,'9700562','윤영석 (국민의힘)','첨단전략산업특별위원회'),(_binary '',26,'9700051','변재일 (더불어민주당)','윤리특별위원회'),(_binary '\0',27,NULL,NULL,'미배정'),(_binary '\0',38,'9700552','UNKNOWN','민생경제안정 특별위원회'),(_binary '\0',39,'9700546','UNKNOWN','정치개혁 특별위원회');
/*!40000 ALTER TABLE `committee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04  0:53:55
